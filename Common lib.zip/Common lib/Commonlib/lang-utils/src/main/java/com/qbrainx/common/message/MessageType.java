package com.qbrainx.common.message;

public enum MessageType {
    ERROR,
    PARAM,
    INFO
}
