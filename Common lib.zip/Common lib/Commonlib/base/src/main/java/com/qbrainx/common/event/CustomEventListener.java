package com.qbrainx.common.event;

import org.springframework.context.event.EventListener;

@EventListener
public @interface CustomEventListener {
}
