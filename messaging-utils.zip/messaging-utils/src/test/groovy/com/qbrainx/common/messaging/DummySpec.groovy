//package com.qbrainx.common.messaging
//
//import spock.lang.Specification
//
//
//class DummySpec extends Specification {
//
//    def "dummy spec wil be removed"() {
//        when:
//        def value = Person.of("Name")
//
//        then:
//        value
//    }
//}