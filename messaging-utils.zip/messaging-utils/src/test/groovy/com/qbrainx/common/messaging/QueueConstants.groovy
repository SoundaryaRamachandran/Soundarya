//package com.qbrainx.common.messaging
//
//class QueueConstants {
//
//    public static final String topicExchangeName = "spring-boot-exchange"
//
//    public static final String firstQueue = "first-queue"
//    public static final String secondQueue = "second-queue"
//    public static final String thirdQueue = "third-queue"
//
//
//}
