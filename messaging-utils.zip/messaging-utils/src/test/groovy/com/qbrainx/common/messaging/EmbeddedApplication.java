//package com.qbrainx.common.messaging;
//
//import org.springframework.amqp.core.Binding;
//import org.springframework.amqp.core.Queue;
//import org.springframework.amqp.core.TopicExchange;
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.context.annotation.Bean;
//import static com.qbrainx.common.messaging.QueueConstants.*;
//import static org.springframework.amqp.core.BindingBuilder.bind;
//
//@SpringBootApplication
//@EnableCustomMessaging
//class EmbeddedApplication {
//
//    public static void main(String[] args) {
//        SpringApplication.run(EmbeddedApplication.class, args);
//    }
//
//    @Bean
//    Queue firstQueue() {
//        return new Queue(firstQueue, true);
//    }
//
//    @Bean
//    Queue secondQueue() {
//        return new Queue(secondQueue, true);
//    }
//
//    @Bean
//    Queue thirdQueue() {
//        return new Queue(thirdQueue, true);
//    }
//
//    @Bean
//    TopicExchange exchange() {
//        return new TopicExchange(topicExchangeName, true, false);
//    }
//
//    @Bean
//    Binding binding(Queue firstQueue, TopicExchange exchange) {
//        return bind(firstQueue).to(exchange).with("foo.bar.#");
//    }
//
//    @Bean
//    Binding secondBinding(Queue secondQueue, TopicExchange exchange) {
//        return bind(secondQueue).to(exchange).with("foo.bar.#");
//    }
//
//    @Bean
//    Binding thirdBinding(Queue thirdQueue, TopicExchange exchange) {
//        return bind(thirdQueue).to(exchange).with("test.#");
//    }
//}
