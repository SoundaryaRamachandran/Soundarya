//package com.qbrainx.common.messaging
//
//import org.springframework.amqp.rabbit.core.RabbitOperations
//import org.springframework.beans.factory.annotation.Autowired
//import org.springframework.boot.test.context.SpringBootTest
//import org.springframework.test.context.ActiveProfiles
//import spock.lang.Ignore
//import spock.lang.Specification
//
//import static com.qbrainx.common.messaging.QueueConstants.*
//
//@Ignore(value = "This test case requires local rabbitmq server")
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = [EmbeddedApplication])
//@ActiveProfiles("rabbitmq")
//class RabbitMqMessagingIntegrationSpec extends Specification {
//
//    @Autowired
//    private RabbitOperations rabbitOperations
//
//
//    def "send and receive messages with same routing key"() {
//        given:
//        def person = Person.of("Ram")
//
//        when:
//        rabbitOperations.convertAndSend(topicExchangeName, "foo.bar", person)
//
//        then:
//        def firstQueue = rabbitOperations.receiveAndConvert(firstQueue)
//        firstQueue == person
//
//        def secondQueueMessage = rabbitOperations.receiveAndConvert(secondQueue)
//        secondQueueMessage == person
//
//        then: "check third queue not received the message"
//        rabbitOperations.receive(thirdQueue) == null
//    }
//}