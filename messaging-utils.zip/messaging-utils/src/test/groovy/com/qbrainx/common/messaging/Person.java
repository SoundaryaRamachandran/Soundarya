//package com.qbrainx.common.messaging;
//
//import org.apache.commons.lang3.builder.EqualsBuilder;
//import org.apache.commons.lang3.builder.HashCodeBuilder;
//
//public class Person {
//
//    private String name;
//
//    public static Person of(final String theName) {
//        final Person person = new Person();
//        person.name = theName;
//        return person;
//    }
//
//    public void setName(final String name) {
//        this.name = name;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    @Override
//    public boolean equals(final Object o) {
//        if (this == o) {
//            return true;
//        }
//
//        if (o == null || getClass() != o.getClass()) {
//            return false;
//        }
//
//        final Person person = (Person) o;
//
//        return new EqualsBuilder()
//            .append(name, person.name)
//            .isEquals();
//    }
//
//    @Override
//    public int hashCode() {
//        return new HashCodeBuilder(17, 37)
//            .append(name)
//            .toHashCode();
//    }
//}
