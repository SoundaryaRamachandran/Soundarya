package com.qbrainx.common.messaging;

import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@Import(CustomMessagingConfiguration.class)
public @interface EnableCustomMessaging {
}
