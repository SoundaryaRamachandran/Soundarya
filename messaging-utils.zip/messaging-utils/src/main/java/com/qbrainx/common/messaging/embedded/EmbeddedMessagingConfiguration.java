package com.qbrainx.common.messaging.embedded;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.fridujo.rabbitmq.mock.MockConnectionFactory;
import lombok.extern.log4j.Log4j2;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.RabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@ConditionalOnProperty(value = "dijta.messaging.type", havingValue = "embedded", matchIfMissing = true)
@Configuration
@Log4j2
public class EmbeddedMessagingConfiguration {

    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    @Bean
    @ConditionalOnMissingBean
    public MessageConverter messageConverter(final ObjectMapper objectMapper) {
        return new Jackson2JsonMessageConverter(objectMapper);
    }

    @Bean
    public ConnectionFactory mockConnectionFactory() {
        log.info("Loading Embedded Mock Messaging Configuration");
        return new CachingConnectionFactory(new MockConnectionFactory());
    }

    @Bean
    public RabbitListenerContainerFactory<SimpleMessageListenerContainer> container(final ConnectionFactory connectionFactory) {

        final SimpleRabbitListenerContainerFactory listenerContainerFactory =
            new SimpleRabbitListenerContainerFactory();

        listenerContainerFactory.setErrorHandler(error -> log.debug("Handling error : {} ", error.getMessage(), error));
        listenerContainerFactory.setChannelTransacted(true);

        listenerContainerFactory.setConnectionFactory(connectionFactory);

        return listenerContainerFactory;
    }

}
