package com.qbrainx.common.messaging;

import com.qbrainx.common.messaging.embedded.EmbeddedMessagingConfiguration;
import com.qbrainx.common.messaging.rabbitmq.CustomRabbitMqMessagingConfiguration;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ComponentScan("com.dijta.common.messaging")
@EnableConfigurationProperties(CustomMessagingProperties.class)
@Import({EmbeddedMessagingConfiguration.class, CustomRabbitMqMessagingConfiguration.class})
public class CustomMessagingConfiguration {
}
