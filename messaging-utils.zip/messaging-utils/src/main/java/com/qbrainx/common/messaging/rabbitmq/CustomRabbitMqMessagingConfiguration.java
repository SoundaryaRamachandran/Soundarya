package com.qbrainx.common.messaging.rabbitmq;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.qbrainx.common.messaging.CustomMessagingProperties;
import com.qbrainx.common.messaging.Validations;

import lombok.extern.log4j.Log4j2;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionNameStrategy;
import org.springframework.amqp.rabbit.connection.SimplePropertyValueConnectionNameStrategy;
import org.springframework.amqp.rabbit.core.RabbitOperations;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.RabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.util.backoff.ExponentialBackOff;

import java.util.Optional;

@ConditionalOnProperty(value = "dijta.messaging.type", havingValue = "rabbitmq")
@Configuration
@Log4j2
public class CustomRabbitMqMessagingConfiguration {

    private final CustomMessagingProperties.RabbitMqProperties rabbitMq;

    public CustomRabbitMqMessagingConfiguration(final CustomMessagingProperties dijtaMessagingProperties) {
        log.info("Loading Rabbitmq configuration with properties {} ", dijtaMessagingProperties);

        this.rabbitMq = dijtaMessagingProperties.getRabbitmq();
        validateMandatoryProperties();
    }

    private void validateMandatoryProperties() {

        final CustomMessagingProperties.Broker broker = rabbitMq.getBroker();

        if (broker.getUri().isPresent() && broker.getHost().isPresent()) {
            throw new IllegalStateException(
                "Either provide host or uri! Both properties are not supported.");
        }

        Validations.notBlank(rabbitMq.getConcurrency(), "property dijta.messaging.rabbitmq.concurrency ");

        if (rabbitMq.getConnectionTimeout() <= 0) {
            throw new IllegalStateException(
                "The property dijta.messaging.rabbitmq.connection-timeout must be greater than zero.");
        }

        if (rabbitMq.getIdleEventInterval().isPresent() && rabbitMq.getIdleEventInterval().get() <= 0) {
            throw new IllegalStateException(
                "The property dijta.messaging.rabbitmq.idle-event-interval must be greater than zero.");
        }

        final CustomMessagingProperties.BackOff backOff = rabbitMq.getBackOff();
        if (backOff.getInitialInterval() <= 0) {
            throw new IllegalStateException(
                "The property dijta.messaging.rabbitmq.back-off.initial-interval must be greater than zero.");
        }

        if (backOff.getMaxInterval() <= 0) {
            throw new IllegalStateException(
                "The property dijta.messaging.rabbitmq.back-off.max-interval must be greater than zero.");
        }

        if (backOff.getMultiplier() <= 0.0) {
            throw new IllegalStateException(
                "The property dijta.messaging.rabbitmq.back-off.multiplier must be greater than zero.");
        }

    }

    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    @Bean
    @ConditionalOnMissingBean
    public MessageConverter messageConverter(final ObjectMapper objectMapper) {
        return new Jackson2JsonMessageConverter(objectMapper);
    }

    @Bean
    public RabbitOperations rabbitOperations(
        final ConnectionFactory rabbitConnectionFactory,
        final MessageConverter messageConverter) {

        final RabbitTemplate rabbitTemplate = new RabbitTemplate(rabbitConnectionFactory);
        rabbitTemplate.setMessageConverter(messageConverter);

        checkAndAddRetry().ifPresent(rabbitTemplate::setRetryTemplate);

        return rabbitTemplate;
    }

    private Optional<RetryTemplate> checkAndAddRetry() {
        if (rabbitMq.isRetryEnabled()) {
            final CustomMessagingProperties.Retry retry = rabbitMq.getRetry();
            final RetryTemplate retryTemplate = new RetryTemplate();

            final SimpleRetryPolicy simpleRetryPolicy = new SimpleRetryPolicy(retry.getMaxAttempts());
            retryTemplate.setRetryPolicy(simpleRetryPolicy);

            final ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
            backOffPolicy.setInitialInterval(retry.getInitialInterval());
            backOffPolicy.setMultiplier(retry.getMultiplier());
            backOffPolicy.setMaxInterval(retry.getMaxInterval());
            retryTemplate.setBackOffPolicy(backOffPolicy);

            return Optional.of(retryTemplate);
        }
        return Optional.empty();
    }

    @Bean
    public ConnectionNameStrategy springApplicationConnectionName() {
        return new SimplePropertyValueConnectionNameStrategy("spring.application.name");
    }

    @Bean
    public ConnectionFactory rabbitConnectionFactory(final ConnectionNameStrategy connectionNameStrategy) {
        final CachingConnectionFactory cachingConnectionFactory = new CachingConnectionFactory();

        final CustomMessagingProperties.Broker broker = rabbitMq.getBroker();
        broker.getUri().ifPresent(cachingConnectionFactory::setUri);
        broker.getHost().ifPresent(cachingConnectionFactory::setHost);
        broker.getUser().ifPresent(cachingConnectionFactory::setUsername);
        broker.getPassword()
            .map(String::new)
            .ifPresent(cachingConnectionFactory::setPassword);
        cachingConnectionFactory.setConnectionTimeout(rabbitMq.getConnectionTimeout());
        cachingConnectionFactory.setConnectionNameStrategy(connectionNameStrategy);

        return cachingConnectionFactory;
    }

    @Bean
    public RabbitListenerContainerFactory<SimpleMessageListenerContainer> container(final ConnectionFactory connectionFactory) {

        final SimpleRabbitListenerContainerFactory listenerContainerFactory =
            new SimpleRabbitListenerContainerFactory();

        final CustomMessagingProperties.BackOff backOff = rabbitMq.getBackOff();

        final ExponentialBackOff exponentialBackOff =
            new ExponentialBackOff(backOff.getInitialInterval(), backOff.getMultiplier());
        exponentialBackOff.setMaxInterval(backOff.getMaxInterval());
        exponentialBackOff.setMaxElapsedTime(backOff.getMaxElapsedTime());

        listenerContainerFactory.setRecoveryBackOff(exponentialBackOff);
        listenerContainerFactory.setErrorHandler(error -> log.debug("Handling error : {} ", error.getMessage(), error));
        listenerContainerFactory.setChannelTransacted(rabbitMq.isChannelTransacted());
        rabbitMq.getIdleEventInterval().ifPresent(listenerContainerFactory::setIdleEventInterval);

        listenerContainerFactory
            .setContainerCustomizer(
                container -> container.setConcurrency(rabbitMq.getConcurrency()));

        listenerContainerFactory.setConnectionFactory(connectionFactory);

        return listenerContainerFactory;
    }

}


