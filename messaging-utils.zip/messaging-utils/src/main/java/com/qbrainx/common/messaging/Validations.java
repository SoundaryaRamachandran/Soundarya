package com.qbrainx.common.messaging;

import org.apache.commons.lang3.StringUtils;

public class Validations {

    public static String notBlank(final String stringToTest, final String message) {
        if (StringUtils.isBlank(stringToTest)) {
            throw new IllegalStateException("The " + message + " must be present");
        }

        return stringToTest;
    }

}
