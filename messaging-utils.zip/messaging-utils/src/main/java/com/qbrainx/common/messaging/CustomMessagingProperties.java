package com.qbrainx.common.messaging;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Optional;

@Getter
@Setter
@ConfigurationProperties("dijta.messaging")
public class CustomMessagingProperties {

    /**
     * Messaging type.
     */
    private MessagingType type = MessagingType.EMBEDDED;

    /**
     * Mandatory properties for rabbitmq messaging type
     */
    private RabbitMqProperties rabbitmq = new RabbitMqProperties();

    @Getter
    @Setter
    public static class RabbitMqProperties {
        /**
         * Broker connection properties
         */
        private Broker broker = new Broker();
        /**
         * Minimum number of listener invoker threads and Maximum number of listener invoker threads. "1-1"
         */
        private String concurrency = "1";
        /**
         * How often idle container events should be published.
         */
        private Optional<Long> idleEventInterval = Optional.empty();
        /**
         * Set the TCP connection timeout.
         */
        private int connectionTimeout = 60000;
        /**
         * Specify the interval between recovery attempts.
         */
        private BackOff backOff = new BackOff();
        /**
         * Whether publishing retries are enabled.
         */
        private boolean retryEnabled;
        /**
         * Optional properties for a retry policy and template..
         */
        private Retry retry = new Retry();
        /**
         * Flag to indicate that channels created by this component will be transactional.
         */
        private boolean channelTransacted;

    }

    @Getter
    @Setter
    public static class Broker {
        /**
         * Convenience property for setting the fields in an AMQP URI: host, port, username, password and virtual host.
         * If any part of the URI is omitted, the ConnectionFactory's corresponding variable is left unchanged.  Note
         * that not all valid AMQP URIs are accepted; in particular, the hostname must be given if the port, username or
         * password are given, and escapes in the hostname are not permitted.
         */
        private Optional<String> uri = Optional.empty();
        /**
         * the default host to use for connection
         */
        private Optional<String> host = Optional.of("localhost");
        /**
         * the default port to use for connection
         */
        private int port = 5672;
        /**
         * The AMQP user name to use when connecting to the broker
         */
        private Optional<String> user = Optional.of("guest");
        /**
         * The password to use when connecting to the broker
         */
        private Optional<char[]> password = Optional.of("guest".toCharArray());

    }

    @Getter
    @Setter
    public static class BackOff {

        /**
         * The initial interval in milliseconds.
         */
        private long initialInterval = 2000L;

        /**
         * The value to multiply the current interval by for each retry attempt.
         */
        private double multiplier = 1.5;

        /**
         * The maximum back off time.
         */
        private long maxInterval = 30000L;

        /**
         * The maximum elapsed time in milliseconds
         */
        private long maxElapsedTime = 30000L;
    }

    public enum MessagingType {
        /**
         * RabbitMq Configuration will be loaded.
         */
        RABBITMQ,
        /**
         * Embedded RabbitMq Configuration will be loaded.
         */
        EMBEDDED
    }

    @Getter
    @Setter
    public static class Retry {

        /**
         * Duration between the first and second attempt to deliver a message.
         */
        private long initialInterval = 100L;
        /**
         * Multiplier to apply to the previous retry interval.
         */
        private double multiplier = 2;
        /**
         * Maximum duration between attempts.
         */
        private long maxInterval = 30000L;
        /**
         * Maximum number of attempts to deliver a message.
         */
        private int maxAttempts = 3;
    }
}
